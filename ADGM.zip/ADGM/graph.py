import os
import json
import logging
from typing import TypedDict, List, Optional

from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, END

from checker import identify_document_type, identify_legal_process, load_checklist, check_required_documents
from commenter import insert_comments_into_docx
from parser import read_docx_text
from rag_engine import get_red_flags_from_gemini

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define the state for our graph
class GraphState(TypedDict):
    uploaded_files: List[str]
    doc_contents: List[dict]
    doc_types: List[str]
    legal_process: Optional[str]
    checklist: Optional[dict]
    red_flags: List[dict]
    reviewed_files: List[str]
    summary: dict

def read_documents_node(state):
    doc_contents = []
    for file_path in state["uploaded_files"]:
        text = read_docx_text(file_path)
        doc_contents.append({"path": file_path, "text": text})
    return {"doc_contents": doc_contents}

def identify_doc_types_node(state):
    doc_types = [identify_document_type(doc["text"], doc["path"]) for doc in state["doc_contents"]]
    return {"doc_types": doc_types}

def identify_legal_process_node(state):
    process = identify_legal_process(state["doc_types"], state["doc_contents"])
    return {"legal_process": process}

def load_checklist_node(state):
    checklist_path = f"data/checklists/{state['legal_process']}.json"
    if not os.path.exists(checklist_path):
        checklist_path = "data/checklists/company_incorporation.json"
    checklist = load_checklist(checklist_path)
    return {"checklist": checklist}

def red_flag_analysis_node(state):
    red_flags = []
    for doc in state["doc_contents"]:
        flags = get_red_flags_from_gemini(doc["text"])
        red_flags.append({"document": os.path.basename(doc["path"]), "flags": flags})
    return {"red_flags": red_flags}

def create_reviewed_documents_node(state):
    reviewed_files = []
    for item in state["red_flags"]:
        doc_name = item["document"]
        flags = item["flags"]
        
        # Find the original path
        original_path = next((doc["path"] for doc in state["doc_contents"] if os.path.basename(doc["path"]) == doc_name), None)
        if not original_path:
            continue

        output_path = f"outputs/{doc_name.replace('.docx', '_reviewed.docx')}"
        
        # Clean and parse JSON output
        if flags and flags.startswith("```json"):
            flags = flags.replace("```json", "").strip()
        if flags and flags.endswith("```"):
            flags = flags[:-3].strip()

        try:
            issues = json.loads(flags) if flags else []
        except json.JSONDecodeError:
            issues = []

        insert_comments_into_docx(original_path, issues, output_path)
        reviewed_files.append(output_path)
        
    return {"reviewed_files": reviewed_files}

def summarize_node(state):
    check_result = check_required_documents(state["doc_types"], state["checklist"])
    
    summary = {
        "process": check_result["process"],
        "documents_uploaded": check_result["documents_uploaded"],
        "required_documents": check_result["required_documents"],
        "missing_documents": check_result["missing_documents"],
        "documents": state["red_flags"]
    }
    
    return {"summary": summary}

def build_graph():
    workflow = StateGraph(GraphState)

    workflow.add_node("read_documents", read_documents_node)
    workflow.add_node("identify_doc_types", identify_doc_types_node)
    workflow.add_node("identify_legal_process", identify_legal_process_node)
    workflow.add_node("load_checklist", load_checklist_node)
    workflow.add_node("red_flag_analysis", red_flag_analysis_node)
    workflow.add_node("create_reviewed_documents", create_reviewed_documents_node)
    workflow.add_node("summarize", summarize_node)

    workflow.set_entry_point("read_documents")
    workflow.add_edge("read_documents", "identify_doc_types")
    workflow.add_edge("identify_doc_types", "identify_legal_process")
    workflow.add_edge("identify_legal_process", "load_checklist")
    workflow.add_edge("load_checklist", "red_flag_analysis")
    workflow.add_edge("red_flag_analysis", "create_reviewed_documents")
    workflow.add_edge("create_reviewed_documents", "summarize")
    workflow.add_edge("summarize", END)

    return workflow.compile()

def run_graph(files):
    if not files:
        return "Please upload at least one .docx file.", None

    os.makedirs("outputs", exist_ok=True)
    
    graph = build_graph()
    
    initial_state = {
        "uploaded_files": [f.name for f in files],
        "doc_contents": [],
        "doc_types": [],
        "legal_process": None,
        "checklist": None,
        "red_flags": [],
        "reviewed_files": [],
        "summary": {}
    }
    
    final_state = graph.invoke(initial_state)
    
    return final_state
