# parser.py

from docx import Document

def read_docx_text(file_path):
    """
    Reads a .docx file and returns its full text as a string.
    """
    doc = Document(file_path)
    full_text = []
    for para in doc.paragraphs:
        if para.text.strip():
            full_text.append(para.text.strip())
    return "\n".join(full_text)
