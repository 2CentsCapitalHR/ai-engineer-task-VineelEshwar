# commenter.py
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def add_comment(paragraph, text, author, initials):
    """
    Adds a comment to the specified paragraph.
    """
    comment = OxmlElement('w:comment')
    comment.set(qn('w:id'), '0')
    comment.set(qn('w:author'), author)
    comment.set(qn('w:initials'), initials)
    
    p = OxmlElement('w:p')
    r = OxmlElement('w:r')
    t = OxmlElement('w:t')
    t.text = text
    r.append(t)
    p.append(r)
    comment.append(p)
    
    comment_ref = OxmlElement('w:commentReference')
    comment_ref.set(qn('w:id'), '0')
    
    run = paragraph.add_run()
    run._r.append(comment_ref)
    run._r.append(comment)

def insert_comments_into_docx(input_path, issues, output_path):
    """
    Inserts comments into a .docx file based on a list of issues.
    """
    doc = Document(input_path)
    
    for i, issue in enumerate(issues):
        section_text = issue.get("section", "").lower()
        comment_text = f"[{issue.get('severity', 'N/A')}] {issue.get('issue', 'No issue specified.')}\n\nSuggestion: {issue.get('suggestion', 'No suggestion.')}"
        
        found = False
        for para in doc.paragraphs:
            if section_text and section_text in para.text.lower():
                add_comment(para, comment_text, "Corporate Agent", "CA")
                
                # Highlight the text for visibility
                run = para.add_run(f" (Review Issue {i+1})")
                run.font.color.rgb = RGBColor(255, 0, 0)
                run.font.bold = True
                found = True
                break
                
        if not found:
            # If the specific section isn't found, add a general comment at the end
            p = doc.add_paragraph()
            add_comment(p, f"Regarding '{section_text}': {comment_text}", "Corporate Agent", "CA")
            run = p.add_run(f"Unmatched Comment: See details for Issue {i+1}")
            run.font.color.rgb = RGBColor(200, 0, 0)
            run.font.italic = True

    doc.save(output_path)
