import gradio as gr
import os
import json
import zipfile
import logging
from graph import run_graph

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def analyze_and_package(files):
    if not files:
        return "Please upload at least one .docx file.", None

    final_state = run_graph(files)

    if not final_state or "summary" not in final_state:
        return "An error occurred during analysis.", None

    summary = final_state["summary"]
    reviewed_files = final_state["reviewed_files"]

    # Save final summary JSON
    summary_path = "outputs/summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    # Zip all outputs
    zip_path = "outputs/final_review_package.zip"
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for file_path in reviewed_files:
            if os.path.exists(file_path):
                zipf.write(file_path, arcname=os.path.basename(file_path))
        if os.path.exists(summary_path):
            zipf.write(summary_path, arcname="summary.json")

    # Prepare the status message
    status_message = "✅ All documents analyzed successfully."
    if summary.get("missing_documents"):
        missing_docs_str = ", ".join(summary["missing_documents"])
        status_message = f"⚠️ It appears that you’re trying to complete the '{summary['process']}' process. Based on our reference list, you have uploaded {summary['documents_uploaded']} out of {summary['required_documents']} required documents. The missing document(s) appear to be: {missing_docs_str}."

    return status_message, zip_path

# Gradio UI
demo = gr.Interface(
    fn=analyze_and_package,
    inputs=gr.File(file_types=[".docx"], label="Upload .docx files", file_count="multiple"),
    outputs=[
        gr.Textbox(label="Status"),
        gr.File(label="Download ZIP (Reviewed Docs + Summary)")
    ],
    title="ADGM Compliance Reviewer (Multiple Files)",
    description="Upload multiple ADGM-related .docx files. This tool will check for missing documents, review each, and return a ZIP with marked-up Word files and a summary report."
)

if __name__ == "__main__":
    demo.launch()
