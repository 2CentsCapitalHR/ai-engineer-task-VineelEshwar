import os
import json
from dotenv import load_dotenv
import google.generativeai as genai

# Load API key from .env
load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("GEMINI_API_KEY not found in .env")

# Configure Gemini
genai.configure(api_key=api_key)
model = genai.GenerativeModel("models/gemini-1.5-flash")


def _call_gemini(prompt):
    """A centralized function to call the Gemini API."""
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"Error calling Gemini API: {e}")
        return None

def get_red_flags_from_gemini(document_text):
    # Load ADGM reference data
    try:
        with open("data/adgm_data.json", "r") as f:
            adgm_refs = json.load(f)
    except FileNotFoundError:
        adgm_refs = []

    reference_info = "\n".join(
        [f"- Category: {item.get('category', 'N/A')}, Document Type: {item['document_type']}, Link: {item['link']}" for item in adgm_refs]
    )
    
    # Build prompt with references
    prompt = f"""
You are an AI legal assistant trained in ADGM corporate compliance laws.

Use the following reference list of ADGM document types and links:
{reference_info}

Your task is to review the following legal document and identify potential red flags or non-compliance issues under ADGM law.

Return your output as **valid JSON**, structured like this:

[
  {{
    "section": "Clause 2",
    "issue": "Clause is too vague.",
    "severity": "Medium",
    "reference": "Per ADGM Companies Regulations 2020, Art. 6",
    "suggestion": "Rewrite clause to clarify the limited liability."
  }},
  ...
]

Now analyze this document:

\"\"\"
{document_text}
\"\"\"
"""
    return _call_gemini(prompt)
