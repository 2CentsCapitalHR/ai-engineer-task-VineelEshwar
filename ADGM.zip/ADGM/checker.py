# checker.py

import json
import os
import logging
from parser import read_docx_text
from rag_engine import _call_gemini
from thefuzz import process as fuzz_process

def get_all_document_types_from_checklists():
    """
    Scans all checklist files and returns a unique set of all
    possible 'required_documents'.
    """
    all_docs = set()
    checklist_dir = "data/checklists"
    for filename in os.listdir(checklist_dir):
        if filename.endswith(".json"):
            try:
                with open(os.path.join(checklist_dir, filename), 'r') as f:
                    checklist = json.load(f)
                    for doc in checklist.get("required_documents", []):
                        all_docs.add(doc)
            except (json.JSONDecodeError, KeyError):
                continue
    return list(all_docs)

def load_checklist(path):
    """
    Load the JSON checklist file containing required documents and process name.
    """
    with open(path, 'r') as f:
        return json.load(f)

def check_required_documents(classified_docs, checklist_data):
    """
    Compares uploaded document types against the checklist.
    Returns number uploaded, required, and list of missing documents.
    """
    required = checklist_data["required_documents"]
    missing = [doc for doc in required if doc not in classified_docs]
    return {
        "process": checklist_data["process"],
        "documents_uploaded": len(classified_docs),
        "required_documents": len(required),
        "missing_documents": missing
    }

def identify_document_type(doc_text, file_path=None):
    """
    Identifies the document type by first getting a raw type from an LLM,
    and then fuzzy matching it to a canonical list from the checklists.
    """
    prompt = f"""
You are an expert in ADGM legal documents. Based on the text below, identify the specific type of document.

Return only the document type name (e.g., "Articles of Association", "Employment Contract").

Document Text:
\"\"\"
{doc_text[:4000]}
\"\"\"
"""
    
    raw_doc_type = _call_gemini(prompt)
    logging.info(f"Raw document type from LLM: {raw_doc_type}")
    if not raw_doc_type:
        return "Unknown"

    # Fuzzy match against the canonical list of all possible document types
    canonical_types = get_all_document_types_from_checklists()
    logging.info(f"Canonical document types: {canonical_types}")
    if not canonical_types:
        return raw_doc_type.strip() # Fallback if no checklists are found

    best_match, score = fuzz_process.extractOne(raw_doc_type, canonical_types)
    logging.info(f"Fuzzy match: '{best_match}' with score {score}")
    
    # Only return the match if it's reasonably confident
    return best_match if score >= 80 else "Unknown"

def identify_legal_process(doc_types, doc_contents):
    """
    Identifies the legal process by first using a deterministic match against checklists,
    then using an LLM with document content as a tie-breaker if needed.
    """
    logging.info(f"Identifying legal process for doc types: {doc_types}")
    checklist_dir = "data/checklists"
    scores = {}

    # Stage 1: Deterministic scoring
    for filename in os.listdir(checklist_dir):
        if filename.endswith(".json"):
            try:
                with open(os.path.join(checklist_dir, filename), 'r') as f:
                    checklist = json.load(f)
                
                required = checklist.get("required_documents", [])
                if not required:
                    continue

                matches = sum(1 for doc in doc_types if doc in required)
                score = matches / len(required)
                scores[filename.replace(".json", "")] = score
            except (json.JSONDecodeError, KeyError):
                continue

    if not scores:
        return "company_incorporation"

    # Find the highest score
    max_score = max(scores.values())
    if max_score == 0:
        return "company_incorporation" # Default if no matches found

    # Get all processes with the highest score
    best_processes = [process for process, score in scores.items() if score == max_score]
    logging.info(f"Best matching processes (score {max_score}): {best_processes}")

    # Stage 2: LLM as a tie-breaker
    if len(best_processes) == 1:
        return best_processes[0]
    else:
        # Concatenate snippets of text from each document for the LLM to analyze
        all_text_snippets = "\n---\n".join([doc["text"][:1000] for doc in doc_contents])

        prompt = f"""
You are an expert in ADGM legal processes. I have a set of documents that could belong to multiple processes. 
Please choose the most likely process based on the document types and their content.

Possible Processes:
{', '.join(best_processes)}

Uploaded Document Types:
{', '.join(doc_types)}

Content Snippets from Documents:
\"\"\"
{all_text_snippets}
\"\"\"

Return only the single best process identifier from the list (e.g., 'company_incorporation').
"""
        response = _call_gemini(prompt)
        if response and response.strip() in best_processes:
            logging.info(f"LLM tie-breaker selected: {response.strip()}")
            return response.strip()
        else:
            logging.warning(f"LLM tie-breaker failed. Defaulting to first best match: {best_processes[0]}")
            return best_processes[0]
